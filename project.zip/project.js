const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const framework = express();
var Text ;

framework.use(express.static('public'));
framework.use(bodyParser.urlencoded({ extended: true }));
framework.set('view engine', 'ejs')

framework.get('/', function (req, res) {
  res.render('index', {topic: null, error: null});
})

framework.post('/', function (req, res) {
  let topic = req.body.topic;
  console.log(topic);
  const options = {
	url: `https://api.github.com/search/repositories?q=topic:${topic}&sort=stars&order=desc` ,
	headers: { 'User-Agent': 'MartinBooker' }
  }
  request(options, function (err, response, body) {
    if(err){
      res.render('index', {topic: null, error: 'Error, please try again'});
    } else {
      let repos = JSON.parse(body)
      if(repos.total_count == undefined){
        res.render('index', {topic: null, error: 'Undefined error, please try again'});
      } else {
		Text = '';
		for (var i = 0; i < repos.items.length; i++) {
			Text += ("00000" + repos.items[i].stargazers_count).substr(-5,5) + '*&nbsp&nbsp' + ("00000" + repos.items[i].forks_count).substr(-5,5) + ' b&nbsp&nbsp' + repos.items[i].name + '<br/>'
			}
		res.render('index', {topic: Text, error: null});
      }
    }
  });
})

framework.listen(3000, function () {
  console.log('Project listening on port 3000')
})