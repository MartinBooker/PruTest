const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const app = express()
const apiKey = '0f304b5e45e910b5ab3d6b0a6b4a5a97';

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs')

app.get('/', function (req, res) {
  res.render('index', {weather: null, error: null});
})

app.post('/', function (req, res) {
  let city = req.body.city;
  console.log(city);
  let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`

  request(url, function (err, response, body) {
    if(err){
      res.render('index', {weather: null, error: 'Error, please try again'});
    } else {
      let weather = JSON.parse(body)
      if(weather.main == undefined){
        res.render('index', {weather: null, error: 'Error, please try again'});
      } else {
		var date = new Date(weather.sys.sunset*1000);
		var now = new Date();
		var timestamp = now.getHours() + ":" + ("0" + now.getMinutes()).substr(-2,2);
		var sunset = date.getHours() + ":" + ("0" + date.getMinutes()).substr(-2,2);
		
        let weatherText = `It's ${timestamp}. The temperature is ${weather.main.temp} degrees in ${weather.name}, ${weather.sys.country}. Sunset is at ${sunset}`;
        res.render('index', {weather: weatherText, error: null});
      }
    }
  });
})

app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})